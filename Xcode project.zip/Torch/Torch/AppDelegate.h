//
//  AppDelegate.h
//  Torch
//
//  Created by ArtikusHG on 8/4/17.
//  Copyright © 2017 ArtikusHG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

