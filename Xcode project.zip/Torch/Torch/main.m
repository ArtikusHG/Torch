//
//  main.m
//  Torch
//
//  Created by ArtikusHG on 8/4/17.
//  Copyright © 2017 ArtikusHG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
