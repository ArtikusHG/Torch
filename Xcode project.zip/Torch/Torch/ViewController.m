//
//  ViewController.m
//  Torch
//
//  Created by ArtikusHG on 8/4/17.
//  Copyright © 2017 ArtikusHG. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
UIWindow *flashWindow = nil;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Print that application has launched to the console
    NSLog(@"Application launched");
    // Make the background black
    self.view.backgroundColor = [UIColor blackColor];
}
- (IBAction)flash:(id)sender {
    // If the background is black, make it white on tap, if it is white, make it black.
    if (self.view.backgroundColor == [UIColor blackColor]) {
        // Set the color
        self.view.backgroundColor = [UIColor whiteColor];
        // Write "Enabled torch" to the console
        NSLog(@"Enabled torch");
    } else {
        // Set the color
        self.view.backgroundColor = [UIColor blackColor];
        // Write "Disabled torch" to the console
        NSLog(@"Disabled torch");
    
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}


@end
